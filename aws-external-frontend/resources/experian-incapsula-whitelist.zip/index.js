'use strict';

const ipRangeCheck = require("ip-range-check");
const https = require('https');

/**
 * Do a request with options provided.
 *
 * @param {Object} options
 * @param {Object} data
 * @return {Promise} a promise of request
 */
function doRequest(options, data) {
    return new Promise((resolve, reject) => {
        const req = https.request(options, (res) => {
            res.setEncoding('utf8');
            let responseBody = '';

            res.on('data', (chunk) => {
                responseBody += chunk;
            });

            res.on('end', () => {
                resolve(JSON.parse(responseBody));
            });
        });

        req.on('error', (err) => {
            reject(err);
        });

        req.write(data)
        req.end();
    });
}

exports.handler = async (event) => {
    const request = event.Records[0].cf.request;

    const data = "";

    const options = {
        hostname: 'my.incapsula.com',
        port: 443,
        path: '/api/integration/v1/ips',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': data.length
        }
    }

    const jsonResponse = await doRequest(options, data);
    const ipRanges = jsonResponse.ipRanges.concat(jsonResponse.ipv6Ranges);

    const content = `
        <\!DOCTYPE html>
        <html lang="en">
            <head>
                <meta charset="utf-8">
                <title>Access Denied by the Origin Server</title>
            </head>
            <body>
                <h1>Access Denied by the Origin Server for IP ${request.clientIp}</h1> 
            </body>
        </html>
    `;

    const response = {
        status: '200',
        statusDescription: 'OK',
        headers: {
            'content-type': [{
                key: 'Content-Type',
                value: 'text/html; charset=utf-8',
            }],
            'content-encoding': [{
                key: 'Content-Encoding',
                value: 'UTF-8',
            }],
        },
        body: content,
        bodyEncoding: 'text'
    };

    if (!ipRangeCheck(request.clientIp, ipRanges)) {
        return response;
    }

    return request;
};
